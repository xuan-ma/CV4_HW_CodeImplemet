# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 19:23:52 2019

@author: ww
"""
import numpy as np
import random
import cv2
'''
#       We haven't told RANSAC algorithm this week. So please try to do the reading.
#       And now, we can describe it here:
#       We have 2 sets of points, say, Points A and Points B. We use A.1 to denote the first point in A, 
#       B.2 the 2nd point in B and so forth. Ideally, A.1 is corresponding to B.1, ... A.m corresponding 
#       B.m. However, it's obvious that the matching cannot be so perfect and the matching in our real
#       world is like: 
#       A.1-B.13, A.2-B.24, A.3-x (has no matching), x-B.5, A.4-B.24(This is a wrong matching) ...
#       The target of RANSAC is to find out the true matching within this messy.
#       
#       Algorithm for this procedure can be described like this:
#       1. Choose 4 pair of points randomly in our matching points(将要匹配的点中). Those four called "inlier" (中文： 内点) while 
#          others "outlier" (中文： 外点)
#       2. Get the homography(单应性) of the inliers (变换矩阵)
#       3. Use this computed homography to test all the other outliers. And separated them by using a threshold 
#          into two parts:
#          a. new inliers which is satisfied our computed homography(遍历A、B集合内所有的外点，找到满足上面的矩阵变换的点数对，作为新的内点)
#          b. new outliers which is not satisfied by our computed homography(没有找到匹配的点，即不满足矩阵变换，继续作为外点存在).
#       4. Get our all inliers (new inliers + old inliers) and goto step 2
#       5. As long as there's no changes or we have already repeated step 2-4 k, a number actually can be computed,
#          times, we jump out of the recursion. The final homography matrix will be the one that we want.
#
#       [WARNING!!! RANSAC is a general method. Here we add our matching background to that.]
#
#       Your task: please complete pseudo code(伪代码) (it would be great if you hand in real code!) of this procedure.
#
#       Follow up 1. For step 3. How to do the "test“? Please clarify this in your code/pseudo code
#       Follow up 2. How do decide the "k" mentioned in step 5. Think about it mathematically!
'''
def ransacMatching(A, B):
#           A & B: List of List
    num=4
    threshold = 5.0
    '''
    #step01--随机挑选num个匹配点对mat_ptsA，mat_ptsB,将其他的待匹配的点放在mat_ptsA_others，mat_ptsB_others
    '''
    iter=0
    ktimes=2*k
    while iter < ktimes:
        iter += 1
        list_mat_ptsA=list_mat_ptsB=[]
        ptsA_index=np.random.choice(len(A),num,replace=False)
        ptsB_index=np.random.choice(len(B),num,replace=False)
        for ptA in ptsA_index:
            list_mat_ptsA.append(A.pop(A[ptA]))
    #    mat_ptsA=np.array(list_mat_ptsA)
    #    mat_ptsA_others=np.array(A)
        for ptB in ptsB_index:
            list_mat_ptsB.append(B.pop(B[ptB]))
    #    mat_ptsB=np.array(list_mat_ptsB)
    #    mat_ptsB_others=np.array(B)
        while True:
            mat_ptsA=np.array(list_mat_ptsA)
            mat_ptsA_others=np.array(A)
            mat_ptsB=np.array(list_mat_ptsB)
            mat_ptsB_others=np.array(B)
            '''
            #step02--根据已知的内点计算单应性变换矩阵HomographyMatrix,h
            '''
            h,status = cv2.getPerspectiveTransfrom(mat_ptsA,mat_ptsB)
            for ptA in mat_ptsA_others:
                '''
                #step03 将上述单应性矩阵h作用在A中的其它点上，计算其与B中点的距离，如果距离值小于阈值threshold，则将其加入内点
                '''
                ptA_tfm=np.dot(ptA,h)
                for ptB in mat_ptsB_others:
                    #计算ptA_tfm和ptB两点之间的距离
                    distance = np.linalg.norm(ptB-ptA_tfm)
                    if distance < threshold:
                       '''
                        #step04--ptA和ptB是匹配的点对，记为内点
                       '''
                       ptA_index=A.index(ptA.tolist())
                       list_mat_ptsA.append(A.pop(A[ptA_index]))
                       ptB_index=B.index(ptB.tolist())
                       list_mat_ptsB.append(B.pop(B[ptB_index]))
        '''
        #step05--退出条件：1.矩阵h内的元素值基本不变，偏差小于一个tolerance
                          2.k值应该为找到集合A和B中所有匹配内点以及据此计算出的HomographyMatrix的迭代次数
        '''
    return h

if __name__=='__main__':
    A=[[],[]……]
    B=[[],[]……]
    print('',ransacMatching(A, B))