# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 22:13:10 2019

@author: ww
"""

import numpy as np
import imutils
import cv2

class Stitcher:
    def __init__(self):
    		# determine if we are using OpenCV v3.X 或者更高版本
    	self.isv3 = imutils.is_cv3(or_better=True) 

    def stitch(self, images, ratio=0.75, reprojThresh=4.0, #David Lowe’s ratio范围 [0.7~0.8]；reprojThresh范围 [1~10] 
        showMatches=False):
        		# unpack the images, then detect keypoints and extract
        		# local invariant descriptors from them
        (imageA, imageB) = images #A在左，B在右
        (kpsA, featuresA) = self.detectAndDescribe(imageA)
        (kpsB, featuresB) = self.detectAndDescribe(imageB)
        
        		# match features between the two images
        M = self.matchKeypoints(kpsA, kpsB,
        	featuresA, featuresB, ratio, reprojThresh)
        
        		# if the match is None, then there aren't enough matched
        		# keypoints to create a panorama
        if M is None:
            return None
        
        		# otherwise, apply a perspective warp to stitch the images
        		# together
        (matches, H, status) = M
        (hA, wA) = imageA.shape[:2]
        (hB, wB) = imageB.shape[:2]
        print('hA, wA',hA, wA,'\nhB, wB',hB, wB)
        shift_M=np.array([[1.0, 0,   wA],
                          [0,   1.0, 0],
                          [0,   0,   1.0]]) #imagA平移（wA,0）
        H_1=np.dot(shift_M,H) #获取左边图像到右边图像的投影映射关系
        result = cv2.warpPerspective(imageA, H_1,
                                    (wA + wB, hA))
        result[0:hB, wA:wA+wB] = imageB

    		# check to see if the keypoint matches should be visualized
        if showMatches:
        	vis = self.drawMatches(imageA, imageB, kpsA, kpsB, matches,
        				status)
        
        			# return a tuple of the stitched image and the
        			# visualization
        return (result, vis)
    
    		# return the stitched image
        return result
    
    def detectAndDescribe(self, image):
    		# convert the image to grayscale
    #       '''
    #       为什么要把图片转换为黑白？彩色应该也可以检测关键点,opencv2.x 需要
    #       '''
    	gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    		# check to see if we are using OpenCV 3.X
    	if self.isv3:
    			# detect and extract features from the image
    		descriptor = cv2.xfeatures2d.SIFT_create()
    		(kps, features) = descriptor.detectAndCompute(image, None)
    
    		# otherwise, we are using OpenCV 2.4.X
    	else:
    			# detect keypoints in the image
    		detector = cv2.FeatureDetector_create("SIFT")
    		kps = detector.detect(gray)
    
    			# extract features from the image
    		extractor = cv2.DescriptorExtractor_create("SIFT")
    		(kps, features) = extractor.compute(gray, kps)
    
    		# convert the keypoints from KeyPoint objects to NumPy arrays
    	kps = np.float32([kp.pt for kp in kps])
    
    		# return a tuple of keypoints and features
    	return (kps, features)
    
    def matchKeypoints(self, kpsA, kpsB, featuresA, featuresB,
    		ratio, reprojThresh):
    		# compute the raw matches and initialize the list of actual
    		# matches
           # The "BruteForce" value indicates that we are going to exhaustively(穷举) 
           # compute the Euclidean distance（欧氏距离） between all feature vectors(特征向量) 
           # from both images and find the pairs of descriptors that have the smallest distance.
    #           supported:
    #        .   -   `BruteForce` (it uses L2 )
    #        .   -   `BruteForce-L1`
    #        .   -   `BruteForce-Hamming`
    #        .   -   `BruteForce-Hamming(2)`
    #        .   -   `FlannBased`
    	matcher = cv2.DescriptorMatcher_create("BruteForce") 
    	rawMatches = matcher.knnMatch(featuresA, featuresB, 2) #knn:返回前k个最匹配的特征向量，k=2 
    	matches = []
    
    		# loop over the raw matches
    	for m in rawMatches:
    			# ensure the distance is within a certain ratio of each
    			# other (i.e. Lowe's ratio test)
    #         匹配器对象的属性   
    #        DMatch.distance - Distance between descriptors. The lower, the better it is.描述子之间的距离。越低越好
    #        DMatch.trainIdx - Index of the descriptor in train descriptors, imagB, 训练描述子里的描述子索引
    #        DMatch.queryIdx - Index of the descriptor in query descriptors, imagA, 查询描述子里的描述子索引
    #        DMatch.imgIdx - Index of the train image, 训练图像的索引
              #len(m)=2 确定找到了2个最佳匹配，David Lawo's ratio为最佳匹配和第二佳匹配的距离之比
    		if len(m) == 2 and m[0].distance < m[1].distance * ratio:
                 #trainIdx为匹配描述子在imagB中的index
                 #quaryIdx为匹配描述子在imagA中的index  
    			matches.append((m[0].trainIdx, m[0].queryIdx))
    
    		# computing a homography requires at least 4 matches
    	if len(matches) > 4:
    			# construct the two sets of points
    		ptsA = np.float32([kpsA[i] for (_, i) in matches])
    		ptsB = np.float32([kpsB[i] for (i, _) in matches])
    
    			# compute the homography between the two sets of points
    		(H, status) = cv2.findHomography(ptsA, ptsB, cv2.RANSAC,
    				reprojThresh)
    
    			# return the matches along with the homograpy matrix
    			# and status of each matched point
    		return (matches, H, status)
    
    		# otherwise, no homograpy could be computed
    	return None
    
    def drawMatches(self, imageA, imageB, kpsA, kpsB, matches, status):
    		# initialize the output visualization image
    	(hA, wA) = imageA.shape[:2]
    	(hB, wB) = imageB.shape[:2]
    	vis = np.zeros((max(hA, hB), wA + wB, 3), dtype="uint8")
    	vis[0:hA, 0:wA] = imageA
    	vis[0:hB, wA:] = imageB
    
    		# loop over the matches
    	for ((trainIdx, queryIdx), s) in zip(matches, status):
    			# only process the match if the keypoint was successfully
    			# matched
    		if s == 1:
    				# draw the match
    			ptA = (int(kpsA[queryIdx][0]), int(kpsA[queryIdx][1]))
    			ptB = (int(kpsB[trainIdx][0]) + wA, int(kpsB[trainIdx][1]))
    			cv2.line(vis, ptA, ptB, (0, 255, 0), 1)
    
    		# return the visualization
    	return vis