# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 19:23:52 2019

@author: ww
"""
import cv2
import numpy as np
'''
#    Finish 2D convolution/filtering by your self. 
#    What you are supposed to do can be described as "median blur", which means by using a sliding window 
#    on an image, your task is not going to do a normal convolution, but to find the median value within 
#    that crop.找到滑动窗口(窗口大小应该就是kernel的size)里面的图像中像素位于中间的值
#
#    You can assume your input has only one channel. (a.k.a a normal 2D list/vector)
#    And you do need to consider the padding method and size. There are 2 padding ways: REPLICA & ZERO. When 
#    "REPLICA" is given to you, the padded pixels are same with the border pixels. E.g is [1 2 3] is your
#    image, the padded version will be [(...1 1) 1 2 3 (3 3...)] where how many 1 & 3 in the parenthesis 
#    depends on your padding size. When "ZERO", the padded version will be [(...0 0) 1 2 3 (0 0...)]
#
#    Assume your input's size of the image is W x H, kernel size's m x n. You may first complete a version 
#    with O(W·H·m·n log(m·n)) to O(W·H·m·n·m·n)).
#    Follow up 1: Can it be completed in a shorter time complexity?
'''
def medianBlur(img, kernel, padding_way):
#        img & kernel is List of List; kernel=[m , n] 行，列; padding_way a string
#        Please finish your code under this blank
#    print('img:\n',img)
    rows,cols=img.shape
    #medianBlur卷积之后的图像尺寸和原图像尺寸保持不变
    #padding之后图像尺寸
    add_rows=kernel[0]//2
    add_cols=kernel[1]//2
    rows_pad=rows+add_rows*2 #上下各加add_rows行
    cols_pad=cols+add_cols*2 #上下各加add_cols列
    #创建padding之后的图像矩阵
    img_pad=np.zeros((rows_pad,cols_pad))
    #将原图像的像素值赋给padding的矩阵
    img_pad[add_rows:add_rows+rows,add_cols:add_cols+cols]=img
    if padding_way == 'Zero':
        pass
    if padding_way == 'REPLICA':
        #先padding行,然后padding列
        for i in range(add_rows):
            img_pad[i,add_cols:add_cols+cols]=img[0,:]
            img_pad[rows_pad-1-i,add_cols:add_cols+cols]=img[rows-1,:]
        for i in range(add_cols):
            img_pad[:,i]=img_pad[:,add_cols]
            img_pad[:,cols_pad-1-i]=img_pad[:,add_cols+cols-1]
#    print('img-pad:\n',img_pad)
    #根据kernel尺寸取其中值
    img_MedBlur=img
    for i in range(rows):
        for j in range(cols):
         img_MedBlur[i,j]=np.median(img_pad[i:i+kernel[0],j:j+kernel[1]])   
    return img_MedBlur
if __name__=='__main__':
   img=cv2.imread('lenna.jpg',0)
   kernelsize=[3,3]
   padding_way='ZERO'
#   print('Results:\n',medianBlur(img, kernelsize, padding_way))
   cv2.imshow('img',img)
   cv2.imshow('img_MedBlur',medianBlur(img, kernelsize, padding_way))
   key=cv2.waitKey()
   if key==27:
       cv2.destroyAllWindows()