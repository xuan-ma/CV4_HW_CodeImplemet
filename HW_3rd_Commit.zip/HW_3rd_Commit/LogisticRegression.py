# -*- coding: utf-8 -*-
"""
Created on Sun Jul 14 11:33:22 2019

@author: ww
"""

## Linear Regression
###############################
import numpy as np
import random

def sigmoid_func(x):
    return 1/(1+np.exp(-x))
def inference(w, b, x):        # inference, test, predict, same thing. Run model after training
    pred_y = w * x + b
    return pred_y

def eval_loss(w, b, x_list, gt_y_list):
    avg_loss = 0.0
#    for i in range(len(x_list)):
#        avg_loss += 0.5 * (w * x_list[i] + b - gt_y_list[i]) ** 2    # loss function
    res_vector=sigmoid_func(inference(w,b,np.array(x_list)))-np.array(gt_y_list)
    avg_loss=np.linalg.norm(res_vector)
    avg_loss /= len(gt_y_list)
    return avg_loss

def gradient(pred_y, gt_y, x):
    diff = pred_y - gt_y
    dw = diff * x
    db = diff
    return dw, db

def cal_step_gradient(batch_x_list, batch_gt_y_list, w, b, lr):
    '''
    SGD: 随机梯度下降法，每次只随机选取一个样本计算梯度
    mini batch SGD: 小批量随机梯度下降法：随机抽取一小部分数据计算梯度，而不是利用所有样本 
    '''
    avg_dw, avg_db = 0, 0
    batch_size = len(batch_x_list)
    #print(bat)
#    for i in range(batch_size):
#        pred_y = inference(w, b, batch_x_list[i])	# get label data
#        dw, db = gradient(pred_y, batch_gt_y_list[i], batch_x_list[i])
#        avg_dw += dw
#        avg_db += db
    pred_y=sigmoid_func(inference(w,b,np.array(batch_x_list)))
    diff=pred_y-np.array(batch_gt_y_list)
    diff_w=diff*np.array(batch_x_list)
    avg_dw = np.sum(diff_w)
    diff_b=diff
    avg_db = np.sum(diff_b)
    '''
    avg_dw--loss对w的导数；avg_db--loss对b的导数；
    当avg_dw和avg_db等于零，说明找到极小值，train()中的迭代可终止
    '''
    avg_dw /= batch_size
    avg_db /= batch_size
    w -= lr * avg_dw
    b -= lr * avg_db
    return w, b , avg_dw , avg_db

def train(x_list, gt_y_list, batch_size, lr, max_iter):
    '''
    此函数以最大迭代次数max_iter作为终止条件
    其他的终止条件：找到loss function的极小值(梯度等于0)，或者如何确定找到了loss function的值小于某一规定的threshold(不常用，很难给定)
    '''
    #w,b initial value
    w = 0
    b = 0
    num_samples = len(x_list)
    for i in range(max_iter):
        '''
        np.random.choice(a,size=None,replace=True, p=None):
            从一维array a 或 int 数字a 中，以概率p随机选取大小为size的数据,
            replace表示是否重用元素，即抽取出来的数据是否放回原数组中，默认为true（抽取出来的数据有重复） 
        '''
        batch_idxs = np.random.choice(len(x_list), batch_size)  #有放回的抽取,抽取的样本会重复
        if i ==1 :
            print('batch_idxs:',batch_idxs)
        batch_x = [x_list[j] for j in batch_idxs]
        batch_y = [gt_y_list[j] for j in batch_idxs]
        w, b ,avg_dw , avg_db= cal_step_gradient(batch_x, batch_y, w, b, lr) #w,b既作输入，又为输出
#        print('w:{}, b:{}, avg_dw:{}, avg_db:{}'.format(w, b,avg_dw , avg_db))
#        print('loss is {0}'.format(eval_loss(w, b, x_list, gt_y_list)))
        if abs(avg_dw) < 0.01 and abs(avg_db) < 0.01:
            print('Needed IterNums:',i)
            print('w:{}, b:{}, avg_dw:{}, avg_db:{}'.format(w, b,avg_dw , avg_db))
            print('loss is {0}'.format(eval_loss(w, b, x_list, gt_y_list)))
            break

def gen_sample_data():
    w = random.randint(0, 10) + random.random()		# for noise random.random[0, 1)
    b = random.randint(0, 5) + random.random()
#    print('w_init',w)
#    print('b_init',b)
    num_samples = 100
    x_list = []
    y_list = []
    for i in range(num_samples):
        x = random.randint(0, 100) * random.random()
#        y = w * x + b + random.random() * random.randint(-1, 1)
        y=random.choice([0,1])
        x_list.append(x)
        y_list.append(y)
    print('y_list',y_list)
    return x_list, y_list, w, b

def run():
    x_list, y_list, w, b = gen_sample_data()
    lr = 0.0005
    max_iter = 20000
    train(x_list, y_list, 50, lr, max_iter)
    print('x_average',np.array(x_list).mean())
    print('y_average',np.array(y_list).mean())

if __name__ == '__main__':	# 跑.py的时候，跑main下面的；被导入当模块时，main下面不跑，其他当函数调
    run()